<?php return array (
  'bookings' => 'App\\Http\\Livewire\\Bookings',
  'destinations' => 'App\\Http\\Livewire\\Destinations',
  'packages' => 'App\\Http\\Livewire\\Packages',
  'power-grid-demo-table' => 'App\\Http\\Livewire\\PowerGridDemoTable',
  'users' => 'App\\Http\\Livewire\\Users',
  'users2' => 'App\\Http\\Livewire\\Users2',
);