// Validation errors messages for Parsley
// Load this after Parsley

Parsley.addMessages('sv', {
  dateiso: "Ange ett giltigt datum (ÅÅÅÅ-MM-DD)."
});
